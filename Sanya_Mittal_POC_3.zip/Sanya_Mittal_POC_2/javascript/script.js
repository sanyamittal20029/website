var aboutLinks = document.getElementsByClassName("about-links");
var tabContents = document.getElementsByClassName("tab-contents");

function opentab(tabname) {
    for (aboutLink of aboutLinks) {
        aboutLink.classList.remove("active-link");
    }
    for (tabContent of tabContents) {
        tabContent.classList.remove("active-tab");
    }

    event.currentTarget.classList.toggle("active-link");
    document.getElementById(tabname).classList.add("active-link");
    event.currentTarget.classList.toggle("active-tab");
    document.getElementById(tabname).classList.add("active-tab");

}
const close = document.getElementById("close");
const open = document.getElementById("open");
const menu = document.getElementById("nbar")

close.addEventListener('click', () => {
    menu.style.right = "-200px";
})
open.addEventListener('click', () => {
    menu.style.right = "0";
})

const fname = document.getElementById("name");
const email = document.getElementById("email");
const message = document.getElementById("message");
const form = document.getElementById("form");
const submit = document.getElementById("send");
const errorElement = document.getElementById('error');
const emailError = document.getElementById("email-error");

// var regx = (/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/);


form.addEventListener('submit', (e) => {
    //   let messages = [];
    
    if (fname.value.length < 5) {
        // messages.push('Name is too short');
        errorElement.innerHTML = "Name is too short...";
        document.getElementById("error-icon").style.color = "red";
        document.getElementById("error-icon").style.visibility = "visible";
        document.getElementById("error").style.color = "red";
        fname.style.border = "2px solid red";
        e.preventDefault();

    }
    if (fname.value.length > 20) {
        // messages.push('Too lengthy!');
        errorElement.innerHTML = "Too lengthy...";
        document.getElementById("error-icon").style.color = "red";
        document.getElementById("error-icon").style.visibility = "visible";
        document.getElementById("error").style.color = "red";
        fname.style.border = "2px solid red";
        e.preventDefault();
    }
    if (!email.value.match(/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)) {
        // messages.push('Invalid email Id...');
        emailError.innerHTML = "Invalid email Id...";
        document.getElementById("email-icon").style.color = "red";
        document.getElementById("email-icon").style.visibility = "visible";
        document.getElementById("email-error").style.color = "red";
        email.style.border = "2px solid red";
        e.preventDefault();
    }
    // if (email.value.length < 5) {
    //     // messages.push('Name is too short');
    //     emailError.innerHTML="Invalid email Id...";
    //     document.getElementById("email-icon").style.color = "red";
    //     document.getElementById("email-icon").style.visibility = "visible";
    //     document.getElementById("email-error").style.color = "red";
    //     email.style.border= "2px solid red";
    //     e.preventDefault();
    //   }

    //   if (messages.length > 0) {
    //     e.preventDefault();
    //     errorElement.innerText = messages;

    //   }


})

submit.addEventListener('click', (e) => {
   
    let name= document.getElementById("name").value;
    let email= document.getElementById("email").value;
    let message= document.getElementById("message").value;

    localStorage.setItem('name', fname);
    localStorage.setItem('email', email);
    localStorage.setItem('message', message);

})