const email = document.getElementById("email");

const password = document.getElementById("password");

const form = document.getElementById("form");
const show = document.getElementById("show");
const open = document.getElementById("open");
let flag1 = false;
let flag2 = false;
// let flag3 = false;
// const submit = document.getElementById("send");

form.addEventListener('submit', (e) => {
    
    
    if (!email.value.match(/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)) {
        document.getElementById("email-error").innerHTML = "Invalid email Id";
        document.getElementById("email-error").style.color = "red";
        document.getElementById("em").style.visibility = "visible";
        document.getElementById("em").style.color = "red";
        document.getElementById("email").style.border = "1px solid red";
        e.preventDefault();
        return false;
    }
    else {
        document.getElementById("email-error").innerHTML = "";
        
        document.getElementById("em").style.visibility = "hidden";
        document.getElementById("em").style.color = "black";
        document.getElementById("email").style.border = "1px solid black";
        flag1 = true;
    }
    
    if (!password.value.match(/^[A-Z]/)) {
        document.getElementById("password-error").innerHTML = "Invalid password";
        document.getElementById("password-error").style.color = "red";
        document.getElementById("pa").style.visibility = "visible";
        document.getElementById("pa").style.color = "red";
        document.getElementById("password").style.border = "1px solid red";
        e.preventDefault();
        return false;
    }
    // else {
    //     document.getElementById("password-error").innerHTML = "";
        
    //     document.getElementById("pa").style.visibility = "hidden";
    //     document.getElementById("pa").style.color = "black";
    //     document.getElementById("password").style.border = "1px solid black";
    //     // flag2 = true;
    // }
    else if (!password.value.match(/[a-z0-9!@#$%^&*]{6,20}/)) {
        document.getElementById("password-error").innerHTML = "Invalid password";
        document.getElementById("password-error").style.color = "red";
        document.getElementById("pa").style.visibility = "visible";
        document.getElementById("pa").style.color = "red";
        document.getElementById("password").style.border = "1px solid red";
        e.preventDefault();
        return false;
    }
    else {
        document.getElementById("password-error").innerHTML = "";
        
        document.getElementById("pa").style.visibility = "hidden";
        document.getElementById("pa").style.color = "black";
        document.getElementById("password").style.border = "1px solid black";
        flag2 = true;
    }

    return true;

})
show.addEventListener('click', (e) => {
    if (password.type === "password") {
        document.getElementById("show").style.visibility = "hidden";
        document.getElementById("open").style.visibility = "visible";

        password.type = "text";


    }

    else {
        password.type = "password";
    }

})
open.addEventListener('click', (e) => {
    if (password.type === "text") {
        document.getElementById("show").style.visibility = "visible";
        document.getElementById("open").style.visibility = "hidden";

        password.type = "password";


    }

    else {
        password.type = "text";
    }

})

form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    // let username = document.getElementById("uname").value;
    
    if(flag1 && flag2){
    let records = new Array();
    records=JSON.parse(localStorage.getItem("users"))?JSON.parse(localStorage.getItem("users")):[]
    if(records.some((v)=>{
        return v.email==email && v.password==password;
    })){
        alert("Logged In");
        let user =records.filter((v)=>{
            return v.email==email && v.password==password ;
        })[0]
        localStorage.setItem("name", user.name);
        localStorage.setItem("email", user.email);
        localStorage.setItem("uname", user.username);
        localStorage.setItem("number", user.number);
        window.location.href= "profile.html";
        
    }
    else{
        alert("Not registered");
    }
    }
    
})    