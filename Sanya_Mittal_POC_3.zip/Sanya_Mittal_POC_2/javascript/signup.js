

let form = document.getElementById("form");
let show = document.getElementById("show");
let open = document.getElementById("open");
let flag1 = false;
let flag2 = false;
let flag3 = false;
let flag4 = false;
let flag5 = false;
// let flag6 = false;
// let flag7 = false;
// let flag8 = false;
// let flag9 = false;

// const submit = document.getElementById("send");


form.addEventListener('submit', (e) => {
    let fname = document.getElementById("name");
let email = document.getElementById("email");
let number = document.getElementById("number");
let uname = document.getElementById("uname");
let password = document.getElementById("password");

    if (fname.value.length < 5) {
        document.getElementById("name-error").innerHTML = "Name is too short";
        document.getElementById("name-error").style.color = "red";
        document.getElementById("na").style.visibility = "visible";
        document.getElementById("na").style.color = "red";
        document.getElementById("name").style.border = "1px solid red";
        
        
        e.preventDefault();
        return false;
    }
    //  else {
    //     document.getElementById("name-error").innerHTML = "";
        
    //     document.getElementById("na").style.visibility = "hidden";
    //     document.getElementById("na").style.color = "black";
    //     document.getElementById("name").style.border = "1px solid black";
        
    //     // flag1 = true;
    // }
    else if (fname.value.match(/[0-9]/)) {
        document.getElementById("name-error").innerHTML = "Name cannot have numerical value";
        document.getElementById("name-error").style.color = "red";
        document.getElementById("na").style.visibility = "visible";
        document.getElementById("na").style.color = "red";
        document.getElementById("name").style.border = "1px solid red";
        
        e.preventDefault();
        return false;
    }
    // else {
    //     document.getElementById("name-error").innerHTML = "";
        
    //     document.getElementById("na").style.visibility = "hidden";
    //     document.getElementById("na").style.color = "black";
    //     document.getElementById("name").style.border = "1px solid black";
    //     // flag2 = true;
    // }
    else if (!fname.value.match(/^[A-Z]/)) {
        document.getElementById("name-error").innerHTML = "First letter should be capital";
        document.getElementById("name-error").style.color = "red";
        document.getElementById("na").style.visibility = "visible";
        document.getElementById("na").style.color = "red";
        document.getElementById("name").style.border = "1px solid red";
        
        e.preventDefault();
        return false;
    }
    else {
        document.getElementById("name-error").innerHTML = "";
        
        document.getElementById("na").style.visibility = "hidden";
        document.getElementById("na").style.color = "black";
        document.getElementById("name").style.border = "1px solid black";
        flag1 = true;
    }
    if (!number.value.match(/^[7-9][0-9]{9}$/)) {
        document.getElementById("number-error").innerHTML = "Invalid no.";
        document.getElementById("number-error").style.color = "red";
        document.getElementById("mn").style.visibility = "visible";
        document.getElementById("mn").style.color = "red";
        document.getElementById("number").style.border = "1px solid red";
        e.preventDefault();
        return false;
    }
    else {
        document.getElementById("number-error").innerHTML = "";
        
        document.getElementById("mn").style.visibility = "hidden";
        document.getElementById("mn").style.color = "black";
        document.getElementById("number").style.border = "1px solid black";
        flag2 = true;
    }
    if (!email.value.match(/^[A-Za-z\._\-0-9]*[@][A-Za-z]*[\.][a-z]{2,4}$/)) {
        document.getElementById("email-error").innerHTML = "Invalid email Id";
        document.getElementById("email-error").style.color = "red";
        document.getElementById("em").style.visibility = "visible";
        document.getElementById("em").style.color = "red";
        document.getElementById("email").style.border = "1px solid red";
        e.preventDefault();
        return false;
        
        
    }
    else {
        document.getElementById("email-error").innerHTML = "";
        
        document.getElementById("em").style.visibility = "hidden";
        document.getElementById("em").style.color = "black";
        document.getElementById("email").style.border = "1px solid black";
        flag3 = true;
    }
    if (uname.value.length < 5) {
        document.getElementById("uname-error").innerHTML = "Username is too short";
        document.getElementById("uname-error").style.color = "red";
        document.getElementById("un").style.visibility = "visible";
        document.getElementById("un").style.color = "red";
        document.getElementById("uname").style.border = "1px solid red";
        
        e.preventDefault();
        return false;
    }
    // else {
    //     document.getElementById("uname-error").innerHTML = "";
        
    //     document.getElementById("un").style.visibility = "hidden";
    //     document.getElementById("un").style.color = "black";
    //     document.getElementById("uname").style.border = "1px solid black";
    //     // flag6 = true;
    // }
    else if (uname.length > 20) {
        document.getElementById("uname-error").innerHTML = "Username is too long";
        document.getElementById("uname-error").style.color = "red";
        document.getElementById("un").style.visibility = "visible";
        document.getElementById("un").style.color = "red";
        document.getElementById("uname").style.border = "1px solid red";
        
        e.preventDefault();
        return false;
    }
    else {
        document.getElementById("uname-error").innerHTML = "";
        
        document.getElementById("un").style.visibility = "hidden";
        document.getElementById("un").style.color = "black";
        document.getElementById("uname").style.border = "1px solid black";
        flag4 = true;
    }
    if (!password.value.match(/^[A-Z]/)) {
        document.getElementById("password-error").innerHTML = "Invalid password";
        document.getElementById("password-error").style.color = "red";
        document.getElementById("pa").style.visibility = "visible";
        document.getElementById("pa").style.color = "red";
        document.getElementById("password").style.border = "1px solid red";
        
        e.preventDefault();
        return false;
    }
    // else {
    //     document.getElementById("password-error").innerHTML = "";
        
    //     document.getElementById("pa").style.visibility = "hidden";
    //     document.getElementById("pa").style.color = "black";
    //     document.getElementById("password").style.border = "1px solid black";
    //     // flag8 = true;
    // }
    else if (!password.value.match(/[a-z0-9!@#$%^&*]{6,20}/)) {
        document.getElementById("password-error").innerHTML = "Invalid password";
        document.getElementById("password-error").style.color = "red";
        document.getElementById("pa").style.visibility = "visible";
        document.getElementById("pa").style.color = "red";
        document.getElementById("password").style.border = "1px solid red";
        
        e.preventDefault();
        return false;
     }
     else {
        document.getElementById("password-error").innerHTML = "";
        
        document.getElementById("pa").style.visibility = "hidden";
        document.getElementById("pa").style.color = "black";
        document.getElementById("password").style.border = "1px solid black";
        flag5 = true;
    }

    return true;

    // if(flag1 && flag2 && flag3 && flag4 && flag5){
    // let records = new Array();
    //     records=JSON.parse(localStorage.getItem("users"))?JSON.parse(localStorage.getItem("users")):[]
    //     if(records.some((v)=>{
    //         return v.email.value==email.value;
    //     })){
    //         alert("Already registered!");
    //     }
    //     else{
    //         records.push({
    //             "name":fname.value,
    //             "number":number.value,
    //             "email":email.value,
    //             "username":uname.value,
    //             "password":password.value
    //         })
    //         localStorage.setItem("users", JSON.stringify(records));
    //     }
    // }
    
    
})
show.addEventListener('click', (e) => {
    if (password.type === "password") {
        document.getElementById("show").style.visibility = "hidden";
        document.getElementById("open").style.visibility = "visible";

        password.type = "text";


    }

    else {
        password.type = "password";
    }

})
open.addEventListener('click', (e) => {
    if (password.type === "text") {
        document.getElementById("show").style.visibility = "visible";
        document.getElementById("open").style.visibility = "hidden";

        password.type = "password";


    }

    else {
        password.type = "text";
    }

})


    form.addEventListener('submit', (e) => {
        let name = document.getElementById("name").value;
        let email = document.getElementById("email").value;
        let number = document.getElementById("number").value;
        let uname = document.getElementById("uname").value;
        let password = document.getElementById("password").value;
        
        
        if(flag1 && flag2 && flag3 && flag4 && flag5){
        let records = new Array();
        records=JSON.parse(localStorage.getItem("users"))?JSON.parse(localStorage.getItem("users")):[]
        if(records.some((v)=>{
            return v.email==email;
        })){
            alert("Already registered!");
        }
        else{
            records.push({
                "name":name,
                "number":number,
                "email":email,
                "username":uname,
                "password":password
            })
            localStorage.setItem("users", JSON.stringify(records));
        }
    
        }
    })

